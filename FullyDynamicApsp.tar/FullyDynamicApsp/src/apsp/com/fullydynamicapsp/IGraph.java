package apsp.com.fullydynamicapsp;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This represents undirected graph. This hides internal implementation details.
 */
public interface IGraph {

    IGraph duplicate();

    /**
     * This provides set of vertices of this graph.
     * 
     * @return Set of vertices.
     */
    List<String> getVertices();

    /**
     * Returns the adjacent vertices to the given vertex.
     * 
     * @param vertex
     *            Specified Vertex.
     * @return Adjacent vertices and their distances.
     */
    Map<String, Integer> getAdjVertices(String vertex);

    /**
     * Provides edges of the graph.
     * 
     * @return Set of edges.
     */
    Set<IEdge> getEdges();

    /**
     * Edge distance between the two given vertices
     * 
     * @param source
     *            source vertex
     * @param dests
     *            destination vertex
     * @return the edge weight
     */
    int getEdgeDistance(String source, String dests);

    /**
     * Checks whether given Vertex belongs to this Graph or not.
     * 
     * @param vertex
     *            Vertex to be checked
     * @return true if the given vertex belong to Graph, otherwise false.
     */
    boolean hasVertex(String vertex);

    /**
     * Adds given edge to the underlying graph.
     * 
     * @param edge
     *            Edge to be added
     * @return true if the given edge is added successfully, false otherwise.
     */
    boolean addEdge(IEdge edge);

    /**
     * Adds given vertex to the Graph.
     * 
     * @param vertex
     *            New Vertex to be added
     * @return true if Graph is changed, false otherwise.
     */
    boolean addVertex(String vertex);

    /**
     * Deletes given edge from the graph.
     * 
     * @param edge
     *            Edge to be removed
     * @return true if Graph is changed, false otherwise.
     */
    boolean deleteEdge(IEdge edge);

    /**
     * Checks if the given vertices are connected or not.
     * 
     * @param vertex1
     *            First vertex
     * @param vertex2
     *            Second vertex
     * @return true if the given two vertices are connected, false otherwise
     * @throws IllegalOpException
     *             If the operation can't be performed
     */
    boolean areConnected(String vertex1, String vertex2) throws IllegalOpException;

    /**
     * This returns number of vertices in the current graph.
     * 
     * @return Number of vertices in the graph
     */
    int numOfVertices();

    /**
     * Register listener to get changes in a Graph.
     * 
     * @param listener
     *            Listener to be notified
     * @return true if the registration is done successfully, false otherwise.
     */
    boolean addListener(IGraphListener listener);

    /**
     * Removes the given listener, if it is already registered. If the listener
     * is not there nothing happens.
     * 
     * @param listener
     *            The listener to be removed
     * @return true if it is removed, false otherwise.
     */
    boolean removeListener(IGraphListener listener);

    /**
     * Provides number of connected components.
     * 
     * @return Number of connected components
     */
    int numOfComponents();

    /**
     * This provides source vertices of each connected component.
     * 
     * @return
     */
    List<String> getComponentSource();

    /**
     * This can be called to prepare internal information of the Graph such as
     * connected components, etc...
     */
    void prepare();

}
