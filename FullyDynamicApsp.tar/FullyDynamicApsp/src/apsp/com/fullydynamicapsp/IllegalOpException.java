package apsp.com.fullydynamicapsp;

/**
 * Created by sivareddy.r on 30/3/2017.
 */
public class IllegalOpException extends RuntimeException {

    public IllegalOpException() {
        super(IllegalOpException.class.getSimpleName());
    }

    public IllegalOpException(String msg) {
        super(msg);
    }
}
