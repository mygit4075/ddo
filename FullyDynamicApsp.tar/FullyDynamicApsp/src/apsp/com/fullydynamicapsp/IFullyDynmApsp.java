package apsp.com.fullydynamicapsp;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * This is a distance oracle that handles all pair shortest path. This is
 * dynamic in nature in which it accepts both edge removal and addition.
 */
public interface IFullyDynmApsp {

    /**
     * This deletes an edge.
     * 
     * @param edge
     *            Edge to be removed.
     * @return true if the edge deletion resulted in change, false otherwise.
     */
    boolean delete(IEdge edge);

    /**
     * This adds an edge.
     * 
     * @param edge
     *            Edge to be added.
     * @return true if the edge addition resulted in change, false otherwise.
     */
    boolean add(IEdge edge);

    /**
     * Provides approximation distance between source and destination vertices.
     * 
     * @param source
     *            Source vertex
     * @param dest
     *            Destination vertex
     * @return Approximate distance
     */
    AdvDistance distance(String source, String dest);
}
