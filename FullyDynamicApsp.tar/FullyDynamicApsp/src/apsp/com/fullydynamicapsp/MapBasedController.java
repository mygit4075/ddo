package apsp.com.fullydynamicapsp;

import java.util.Map;

/**
 * Created by sivareddy.r on 24/4/2017.
 */

public class MapBasedController implements ITreeController {

    private final Map<String, Integer> mDistMap;

    public MapBasedController(Map<String, Integer> map) {
        mDistMap = map;
    }

    @Override
    public boolean isAllowed(String vertex, int dist, int weight) {
        return !mDistMap.containsKey(vertex) || (dist + weight) < mDistMap.get(vertex);
    }

    @Override
    public boolean isAllowed(int level) {
        return true;
    }

}
