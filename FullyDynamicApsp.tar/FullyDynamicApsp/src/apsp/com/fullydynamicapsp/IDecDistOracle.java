package apsp.com.fullydynamicapsp;

import java.util.Map;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * This represents decremental distance oracle, which allows edge deletion and
 * answers distance queries.
 */
public interface IDecDistOracle {

    /**
     * Removes an edge.
     * 
     * @param edge
     *            The edge to be removed
     * @return If the edge deletion resulted in change, false otherwise.
     */
    boolean remove(IEdge edge);

    /**
     * Returns distance between source vertex and destination vertex.
     * 
     * @param source
     *            Source vertex
     * @param dest
     *            Destination vertex
     * @return Approximate distance between source and destination.
     */
    AdvDistance distance(String source, String dest);

    /**
     * Adds an edge.
     * 
     * @param edge
     *            Edge to be added
     * @return true if the distance oracle has been changed, false otherwise.
     */
    boolean add(IEdge edge);

    /**
     * Provides nearest nodes of the given vertex level wise.
     * 
     * @param vertex
     *            Vertex for which nearest nodes to be found out
     * @return Map of nearest nodes
     */
    Map<Integer, String> getNearestNodes(String vertex);

}
