package apsp.com.fullydynamicapsp;

/**
 * This represents an edge of a Graph.
 */
public interface IEdge {

    /**
     * Returns weight of the edge in Integer.
     * 
     * @return Integer weight
     */
    int weight();

    /**
     * Updates weight of the edge. Incorrect or not allowed edge weight can lead
     * to this API to return false.
     * 
     * @param weight
     *            New weight
     * @return true if the weight of the edge is updated, false otherwise
     */
    boolean updateWeight(int weight);

    /**
     * Returns vertex to which this edge is out incident.
     * 
     * @return Out incident vertex's label
     */
    String getSourceVertex();

    /**
     * Returns vertex to which this edge is in incident.
     * 
     * @return In incident vertex's label
     */
    String getDestVertex();
}
