package apsp.com.fullydynamicapsp;

/**
 * This represents Even Shiloach edge.
 */
public interface IEsEdge extends IEdge {

    /**
     * Removes this edge.
     * 
     * @return true if it is removed.
     */
    boolean remove();
}
