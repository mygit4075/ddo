package apsp.com.fullydynamicapsp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class GraphReader {

    static IGraph readGraph() {
        IGraph retVal = null;
        BufferedReader reader = null;
        Scanner scanner = null;
        try {
            reader = new BufferedReader(new FileReader(new File("input.txt")));
            scanner = new Scanner(reader);
            int n = scanner.nextInt();
            retVal = new ModernAdjList(n);
            int m = scanner.nextInt();
            for (int i = 0; i < m; i++) {
                int v1 = scanner.nextInt();
                int v2 = scanner.nextInt();
                IEdge edge = new Edge(1, String.valueOf(v1), String.valueOf(v2));
                retVal.addEdge(edge);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
        Log.d("Before Prepare");
        retVal.prepare();
        Log.d("After Prepare");
        return retVal;
    }

}
