package apsp.com.fullydynamicapsp;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JViewport;
import javax.swing.ScrollPaneConstants;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

class JPanelExample extends JFrame {

    private final IGraph mGraph;

    public JPanelExample(IGraph graph) {
        Log.d("JPanelExample Enter");
        mGraph = graph;
        setTitle("Fully Dynamic All Pair Shortest Path");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel panel1 = new JPanel();
        JLabel label = new JLabel("PATH LABEL");
        GraphPanel panel2 = new GraphPanel(mGraph, label);
        panel2.setBackground(Color.WHITE);
        panel1.add(label);
        JScrollPane scrollFrame = new JScrollPane(panel2, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollFrame.setAutoscrolls(true);
        panel2.setScrollPane(scrollFrame);
        setPreferredSize(new Dimension(800, 650));
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panel1, panel2);
        add(splitPane);
        pack();
        setVisible(true);
        Log.d("JPanelExample Exit");
    }

}

public class GraphPanel extends JPanel {

    private final IGraph mGraph;
    private final IFullyDynmApsp mApsp;
    private AdvDistance mAdvDist;
    private JScrollPane mScrollPane;
    private final int mEdgeLimit;

    private String mNode1;
    private String mNode2;

    private final Map<String, Point> mNodeMap;
    private final Map<Point, String> mPointMap;

    private int mouseStartX;
    private int mouseStartY;
    private final JLabel mPathLabel;

    // Constants
    static final int NODE_WIDTH = 20;// In Units
    static final int NODE_HEIGHT = 20;// In Units
    static final int NODE_VERTICAL_DIST = 30; // In Units
    static final int NODE_HORIZONTAL_DIST = 45; // In Units
    static final int TOP_BORDER = 50; // In Units
    static final int LEFT_BORDER = 30; // In Units
    static final int LEVEL_GAP = NODE_VERTICAL_DIST + NODE_HEIGHT; // In Units
    static final int COMP_GAP = 50; // In Units

    static final String FIND_DIST = "Find Distance";
    static final String DEL_EDGE = "Delete Edge";
    static final String ADD_EDGE = "Add Edge";

    private int mAddedCount = 0;

    void setScrollPane(JScrollPane pane) {
        mScrollPane = pane;
    }

    public GraphPanel(IGraph graph, JLabel pathLabel) {
        Log.d("GraphPanel Enter");
        mPathLabel = pathLabel;
        mGraph = graph;
        mEdgeLimit = (int) Math.pow(graph.getEdges().size(), 1.0 / 2);
        GraphListener listener = new GraphListener();
        addMouseListener(listener);
        addMouseMotionListener(listener);
        mNodeMap = new HashMap<>();
        mPointMap = new HashMap<>();
        mApsp = new DynamicDistOracle(graph, 15);
        prepare();
        Log.d("GraphPanel Exit");
    }

    private void prepare() {
        Log.d("GraphPanel Prepare Enter");
        int totalHeight = TOP_BORDER;
        Random rand = new Random();
        int maxWidth = LEFT_BORDER;
        for (int retry = 1; retry <= 10; retry++) {
            try {
                for (String source : mGraph.getComponentSource()) {
                    Map<Integer, List<String>> bfsTree = getBfsTree(source);
                    for (int level = 1; level <= bfsTree.size(); level++) {
                        List<String> nodes = bfsTree.get(level);
                        int m = getWidth(nodes.size());
                        int n = getHeight(nodes.size());
                        int count = 0;
                        for (int i = 0; i < nodes.size(); i++) {
                            int y = totalHeight + rand.nextInt(n);
                            int x = LEFT_BORDER + rand.nextInt(m);
                            // Log.d("X : " + x + " Y : " + y);
                            if (!canPlace(x, y, m + LEFT_BORDER, n + totalHeight)) {
                                // Log.d("Can not place!");
                                i--;
                                count++;
                                if (count >= 10) {
                                    throw new IllegalOpException("Retry again!!");
                                }
                                continue;
                            }
                            count = 0;
                            if (x > maxWidth) {
                                maxWidth = x + NODE_WIDTH;
                            }
                            Point p = new Point(x, y);
                            mNodeMap.put(nodes.get(i), p);
                            mPointMap.put(p, nodes.get(i));
                        }
                        totalHeight += (n + LEVEL_GAP);
                    }
                }
                totalHeight += COMP_GAP;
                Log.d("Success!!");
                break;
            } catch (IllegalOpException e) {
                mNodeMap.clear();
                mPointMap.clear();
                totalHeight = TOP_BORDER;
                maxWidth = LEFT_BORDER;
                Log.d("Restarting Node Points!!");
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e1) {

                }
            }
        }
        Log.d("Max Width : " + maxWidth + " Row : " + totalHeight);

        setPreferredSize(new Dimension(maxWidth, totalHeight));
        Log.d("GraphPanel Prepare Exit");
    }

    private int getHeight(int n) {
        return NODE_HEIGHT * n + (n - 1) * NODE_VERTICAL_DIST;
    }

    private int getWidth(int n) {
        return NODE_WIDTH * n + (n - 1) * NODE_HORIZONTAL_DIST;
    }

    private boolean canPlace(int x, int y, int width, int height) {
        int y1 = y - NODE_VERTICAL_DIST - NODE_HEIGHT;
        if (y1 < TOP_BORDER) {
            y1 = TOP_BORDER;
        }

        int y2 = y + NODE_HEIGHT + NODE_VERTICAL_DIST;
        if (y2 > height) {
            y2 = height;
        }

        int x2 = x + NODE_HORIZONTAL_DIST + NODE_WIDTH;
        if (x2 > width) {
            x2 = width;
        }

        int x1 = x - NODE_HORIZONTAL_DIST - NODE_WIDTH;
        if (x1 < LEFT_BORDER) {
            x1 = LEFT_BORDER;
        }

        boolean retVal = true;

        for (int i = x1; i < x2; i++) {
            for (int j = y1; j < y2; j++) {
                Point p = new Point(i, j);
                if (mPointMap.containsKey(p)) {
                    retVal = false;
                    break;
                }
            }
        }

        return retVal;
    }

    private void updateGraph(Graphics canvas) {
        for (String source : mGraph.getComponentSource()) {
            drawTheGraph(mNodeMap, canvas, source);
        }
    }

    private void drawTheGraph(Map<String, Point> posMap, Graphics canvas, String source) {
        Log.d("DRAW The Graph : ADV DIST " + mAdvDist);

        if (mAdvDist == null) {
            /*
             * The following is the notation for BFS(Breadth First Search).
             */
            // 0: Element is not processed
            // 1: Element is in Queue
            // 2: Element is processed

            Map<String, Integer> processedMap = new HashMap<>();
            Queue<String> queue = new LinkedList<>();
            List<String> list = new LinkedList<>();
            list.add(source);
            queue.add(source);
            drawNode(posMap.get(source), source, canvas);

            while (!queue.isEmpty()) {
                String vertexLabel = queue.remove();
                processedMap.put(vertexLabel, 2);
                if (mGraph.getAdjVertices(vertexLabel) != null) {
                    for (String adjLabel : mGraph.getAdjVertices(vertexLabel).keySet()) {
                        if (processedMap.get(adjLabel) == null) {
                            list.add(adjLabel);
                            queue.add(adjLabel);
                            processedMap.put(adjLabel, 1);
                            drawLine(posMap.get(vertexLabel), posMap.get(adjLabel), canvas, Color.BLACK);
                        } else {
                            drawLine(posMap.get(vertexLabel), posMap.get(adjLabel), canvas, Color.BLACK);
                        }
                    }
                }
            }

            processedMap.clear();
        } else {
            List<String> path = mAdvDist.mPath;
            if (path.size() > 1) {
                for (int i = 0; i < (path.size() - 1); i++) {
                    drawLine(posMap.get(path.get(i)), posMap.get(path.get(i + 1)), canvas, Color.BLUE);
                }
            }
        }

        for (Entry<String, Point> entry : posMap.entrySet()) {
            drawNode(entry.getValue(), entry.getKey(), canvas);
        }
    }

    private void drawLine(Point p1, Point p2, Graphics canvas, Color color) {
        canvas.setColor(color);
        canvas.drawLine(p1.x + (NODE_WIDTH / 2), p1.y + (NODE_HEIGHT / 2), p2.x + (NODE_WIDTH / 2), p2.y
                + (NODE_HEIGHT / 2));
    }

    private void drawNode(Point point, String label, Graphics canvas) {
        if (label.equals(mNode1) || label.equals(mNode2)) {
            canvas.setColor(Color.YELLOW);
        } else {
            canvas.setColor(Color.RED);
        }
        canvas.fillRect(point.x, point.y, NODE_WIDTH, NODE_HEIGHT);
        canvas.setColor(Color.BLACK);
        Font font = new Font(Font.MONOSPACED, Font.BOLD, 15);
        canvas.setFont(font);
        canvas.drawString(label, point.x, point.y);
    }

    private Map<Integer, List<String>> getBfsTree(String source) {
        Map<Integer, List<String>> retVal = new HashMap<Integer, List<String>>();
        /*
         * The following is the notation for BFS(Breadth First Search).
         */
        // 0: Element is not processed
        // 1: Element is in Queue
        // 2: Element is processed

        Map<String, Integer> processedMap = new HashMap<>();
        Queue<String> queue = new LinkedList<>();
        List<String> list = new LinkedList<>();
        queue.add(source);
        list.add(source);
        retVal.put(1, list);
        Map<String, Integer> levelMap = new HashMap<>();
        levelMap.put(source, 1);

        while (!queue.isEmpty()) {
            String vertexLabel = queue.remove();
            processedMap.put(vertexLabel, 2);
            if (mGraph.getAdjVertices(vertexLabel) != null) {
                for (String adjLabel : mGraph.getAdjVertices(vertexLabel).keySet()) {
                    if (processedMap.get(adjLabel) == null) {
                        list = retVal.get(levelMap.get(vertexLabel) + 1);
                        if (list == null) {
                            list = new LinkedList<>();
                            retVal.put(levelMap.get(vertexLabel) + 1, list);
                        }
                        list.add(adjLabel);
                        levelMap.put(adjLabel, levelMap.get(vertexLabel) + 1);
                        queue.add(adjLabel);
                        processedMap.put(adjLabel, 1);
                    }
                }
            }
        }

        processedMap.clear();
        return retVal;
    }

    // Draws the graph
    public void paintComponent(Graphics page) {
        super.paintComponent(page);
        updateGraph(page);
    }

    private Point getNearByPoint(Point p) {
        int x = p.x;
        int y = p.y;
        x -= NODE_WIDTH;
        if (x < LEFT_BORDER) {
            x = LEFT_BORDER;
        }

        y -= NODE_HEIGHT;
        if (y < TOP_BORDER) {
            y = TOP_BORDER;
        }

        Point retVal = null;

        for (int i = x; i < (x + NODE_WIDTH); i++) {
            for (int j = y; j < (y + NODE_HEIGHT); j++) {
                Point tmp = new Point(i, j);
                if (mPointMap.containsKey(tmp)) {
                    retVal = tmp;
                    break;
                }
            }
        }
        return retVal;
    }

    private String getPathString(List<String> path) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < path.size(); i++) {
            if (i >= 1) {
                builder.append(" - ");
            }
            builder.append(path.get(i));
        }
        return builder.toString();
    }

    private void handleNodeSelection() {
        boolean areAdjacent = false;
        if (mGraph.getAdjVertices(mNode1) != null) {
            areAdjacent = mGraph.getAdjVertices(mNode1).containsKey(mNode2);
        }

        String[] options = new String[2];
        options[0] = FIND_DIST;
        if (areAdjacent) {
            options[1] = DEL_EDGE;
        } else {
            options[1] = ADD_EDGE;
        }

        int selection = JOptionPane.showOptionDialog(null, "Select Action", "APSP Option Dialog",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (selection == JOptionPane.YES_OPTION) {
            mAdvDist = mApsp.distance(mNode1, mNode2);
            if (mAdvDist == null) {
                Log.d("NO_PATH");
                resetNodeSelection();
            } else {
                mPathLabel.setText(getPathString(mAdvDist.mPath));
            }
        } else if (selection == JOptionPane.NO_OPTION) {
            if (DEL_EDGE.equals(options[1])) {
                IEdge edge = new Edge(1, mNode1, mNode2);
                mGraph.deleteEdge(edge);
                mApsp.delete(edge);
            } else {
                IEdge edge = new Edge(1, mNode1, mNode2);
                mGraph.addEdge(edge);
                mApsp.add(edge);
            }
            resetNodeSelection();
        } else {
            resetNodeSelection();
        }
        repaint();
        mAddedCount++;
        if (mEdgeLimit <= mAddedCount) {
            mAddedCount = 0;
            mGraph.prepare();
        }
    }

    private void resetNodeSelection() {
        mNode1 = null;
        mNode2 = null;
        mAdvDist = null;
        mPathLabel.setText("PATH LABEL");
        Log.d("Adv Dist Reset!!");
    }

    // The listener for mouse events.
    private class GraphListener implements MouseListener, MouseMotionListener {
        public void mouseClicked(MouseEvent event) {
            Point p = event.getPoint();
           Log.d("X : " + p.x + " Y : " + p.y);
            Point nodeP = getNearByPoint(p);

            if (nodeP == null) {
                if (mNode2 != null) {
                    Log.d("1");
                    resetNodeSelection();
                }
            } else {
                if (mNode2 == null) {
                    if (mNode1 == null) {
                        Log.d("2");
                        mNode1 = mPointMap.get(nodeP);
                    } else {
                        Log.d("3");
                        mNode2 = mPointMap.get(nodeP);
                        repaint();
                        handleNodeSelection();
                        return;
                    }
                } else {
                    Log.d("4");
                    mNode1 = mPointMap.get(nodeP);
                    mNode2 = null;
                    mAdvDist = null;
                }
            }
            repaint();
        }

        public void mousePressed(MouseEvent event) {
            // point1 = event.getPoint();
            mouseStartX = event.getPoint().x;
            mouseStartY = event.getPoint().y;
        }

        public void mouseReleased(MouseEvent event) {
            // point2 = event.getPoint();
            // if (point1.x != point2.x && point1.y != point2.y) {
            // edgeList.add(new Edge(point1, point2));
            // repaint();
            // }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // TODO Auto-generated method stub
        }

        @Override
        public void mouseExited(MouseEvent e) {
            // TODO Auto-generated method stub
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            JViewport viewPort = mScrollPane.getViewport();
            Point vpp = viewPort.getViewPosition();
            vpp.translate(mouseStartX - e.getX(), mouseStartY - e.getY());
            scrollRectToVisible(new Rectangle(vpp, viewPort.getSize()));
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            // TODO Auto-generated method stub

        }
    }

    public static void main(String[] args) {
        Log.d("Before Graph Create");
        (new GraphCreator()).create();
        Log.d("After Graph Create");
        Log.d("Before Graph Read");
        IGraph graph = GraphReader.readGraph();
        Log.d("After Graph Read");
        for (int i = 1; i <= 1; i++) {
            Log.d("Before Fully Dynamic Apsp");
            new JPanelExample(graph);
            // new FullyDynamicDistOracle(graph, 15);
            Log.d("After Fully Dynamic Apsp");
        }
    }
}
