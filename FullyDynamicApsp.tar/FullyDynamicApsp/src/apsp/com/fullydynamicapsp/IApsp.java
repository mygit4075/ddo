package apsp.com.fullydynamicapsp;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * Created by sivareddy.r on 24/4/2017.
 */

public interface IApsp {

    /**
     * Returns distance between source vertex and destination vertex.
     * 
     * @param source
     *            Source vertex
     * @param dest
     *            Destination vertex
     * @return Approximate distance between source and destination.
     */
    AdvDistance distance(String source, String dest);
}
