/*package apsp.com.fullydynamicapsp;

import java.util.List;
import java.util.Map;

 *//**
 * Created by sivareddy.r on 24/4/2017.
 */
/*
 * 
 * public class GraphFactory {
 * 
 * public static IGraph createKunalGraph(IGraph graph, int alpha, int kVal,
 * Map<Integer, List<IVertex>> map) { return new KunalGraph(graph, alpha, kVal,
 * map, 1); }
 * 
 * }
 */