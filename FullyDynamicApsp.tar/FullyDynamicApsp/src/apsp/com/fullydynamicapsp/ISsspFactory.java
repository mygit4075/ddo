package apsp.com.fullydynamicapsp;

/**
 * This is an abstract single source shortest path factory.
 */
public interface ISsspFactory {

    /**
     * Creates an Even Shiloach tree with the given graph and source vertex.
     * 
     * @param graph
     *            A graph
     * @param vertex
     *            Source Vertex
     * @return Single source shortest path tree
     */
    IShortestTree createEvenShiloachTree(IGraph graph, IVertex vertex);

}
