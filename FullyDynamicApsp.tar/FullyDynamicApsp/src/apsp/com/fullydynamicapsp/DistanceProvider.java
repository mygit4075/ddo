package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DistanceProvider {

    private final IGraph mGraph;
    private final Map<String, IShortestTree> mTreeMap;

    public DistanceProvider(IGraph graph) {
        mGraph = graph;
        mTreeMap = new HashMap<>();
        prepare();
    }

    private void prepare() {
        for (String vertex : mGraph.getVertices()) {
            List<String> sources = new ArrayList<>();
            sources.add(vertex);
            mTreeMap.put(vertex, new SingleSrcShortPath(mGraph, new NoController(), sources, "APSP"));
        }
    }

    public int getDistance(String source, String dest) {
        int retVal = -1;
        if (mTreeMap.get(source).contains(dest)) {
            retVal = mTreeMap.get(source).distance(dest);
        }
        return retVal;
    }

}
