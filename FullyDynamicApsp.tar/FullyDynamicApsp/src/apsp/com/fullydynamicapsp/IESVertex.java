package apsp.com.fullydynamicapsp;

import java.util.Queue;
import java.util.Set;

/**
 * This represents Even Shiloach Vertex.
 */
public interface IESVertex extends IVertex {

    int DEF_LEVEL = Integer.MAX_VALUE;
    int DEF_DIST = Integer.MAX_VALUE;

    /**
     * Type of adjacency vertex.
     */
    enum AdjType {
        /**
         * Parent edge. One level less usually.
         */
        PARENT,

        /**
         * Sibling edge. Same level vertex.
         */
        SIBLING,

        /**
         * Child edge. One level below vertex.
         */
        CHILD
    }

    /**
     * This increases level of this vertex by one.
     * 
     * @param queue
     *            Nodes whose level to be inspected are added to the queue
     * @return true if the level is updated successfully, otherwise false.
     */
    boolean increaseLevel(Queue<IESVertex> queue);

    /**
     * Adds an edge with given type.
     * 
     * @param type
     *            Edge type
     * @param vertex
     *            Vertex
     * @param weight
     *            Weight of the edge
     * @return true if the vertex is updated, false otherwise
     */
    boolean addEdge(AdjType type, IESVertex vertex, int weight);

    /**
     * Removes an edge with the given type.
     * 
     * @param type
     *            Edge type
     * @param vertex
     *            Vertex
     * @return true if the vertex is updated, false otherwise.
     */
    boolean removeEdge(AdjType type, IESVertex vertex);

    /**
     * Updates edge with the given type.
     * 
     * @param type
     *            Edge type
     * @param vertex
     *            Vertex
     * @param weight
     *            Weight of the edge
     * @return true if the vertex is updated, false otherwise.
     */
    boolean updateEdge(AdjType type, IESVertex vertex, int weight);

    /**
     * This updates level of this vertex with respect to source vertex by using
     * BFS(Breadth First Search).
     * 
     * @param level
     *            New level
     * @return true if the level of the vertex is onEdgeUpdate, false otherwise.
     * @throws IllegalOpException
     *             If the operations is not allowed.
     */
    boolean updateLevel(int level) throws IllegalOpException;

    /**
     * Checks if this Vertex has any parents.
     * 
     * @return true if it has parents, false otherwise.
     */
    boolean hasNoParents();

    /**
     * This notifies that the node is disconnected from the root of the shortest
     * tree.
     */
    void removeSubTree();

    /**
     * Parents of this vertex.
     * 
     * @return Set of parents
     */
    Set<IESVertex> getParents();

    /**
     * Children of this vertex.
     * 
     * @return Set of children
     */
    Set<IESVertex> getChildren();

    /**
     * Updates distance.
     * 
     * @return true if the distance is update, false otherwise.
     */
    boolean updateDistance();

    /**
     * Removes this node.
     */
    void remove();

    /**
     * Provides path vertex.
     * 
     * @return Vertex
     */
    IESVertex getPathVertex();
}
