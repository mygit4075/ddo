package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Created by sivareddy.r on 22/4/2017.
 */

public class Sampler2 {

    private final int mKVal;
    private final List<IVertex> mVertices;
    private final int mSize;

    public Sampler2(Set<IVertex> vertices, int k) {
        mVertices = new ArrayList<>(vertices);
        mSize = mVertices.size();
        mKVal = k;
    }

    /**
     * Divides set of vertices into mKVal groups. mKVal th group will have no
     * vertices. Group number starts with 1 and ends with mKVal. I th group is
     * created from (I - 1) th group by selecting each vertex of (I - 1) group
     * with probability of 1/(n pow 1/k).
     * 
     * @return
     */
    public Map<Integer, List<IVertex>> sample() {
        Map<Integer, List<IVertex>> verticesGrps = new HashMap<>();
        verticesGrps.put(mKVal, new ArrayList<IVertex>());
        for (int i = 1; i < mKVal; i++) {
            verticesGrps.put(i, getVertices(i));
        }
        return verticesGrps;
    }

    private List<IVertex> getVertices(int index) {
        List<IVertex> retVal = new ArrayList<>();
        int numOfVertices = (int) (Math.pow(mSize, index / mKVal) + 0.5);
        Random random = new Random();
        for (int i = 0; i < numOfVertices; i++) {
            int token = random.nextInt(mSize);
            if (!retVal.contains(mVertices.get(token))) {
                // Ensure vertices are unique
                retVal.add(mVertices.get(token));
            } else {
                i--;
            }
        }
        return retVal;
    }
}
