package apsp.com.fullydynamicapsp;

public class Log {
	
	private static final boolean DEBUG = false;
	
	private void Util() {
		
	}
	
	public static void d(String msg) {
		if(DEBUG){
			dump(msg);
		}
	}
	
	public static void i(String msg) {
		dump(msg);
	}
	
	private static void dump(String msg){
		System.out.println(msg);
	}

}
