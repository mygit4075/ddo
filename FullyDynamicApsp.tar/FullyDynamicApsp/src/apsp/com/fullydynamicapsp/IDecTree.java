package apsp.com.fullydynamicapsp;

import java.util.Set;

/**
 * Created by sivareddy.r on 25/4/2017.
 */

public interface IDecTree extends IShortestTree {

    /**
     * This deletes the given edge. If the given edge is not present nothing
     * happens.
     * 
     * @param edge
     *            Edge to be deleted
     * @return true if there is change to the tree, false otherwise.
     */
    boolean delete(IEdge edge);

    /**
     * Returns set of vertices whose level is increased last time.
     * 
     * @return Set of vertices if any vertices level is increased, false
     *         otherwise.
     */
    Set<String> increasedVertices();
}
