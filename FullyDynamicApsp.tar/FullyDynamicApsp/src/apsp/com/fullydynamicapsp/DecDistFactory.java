package apsp.com.fullydynamicapsp;

/**
 * Decremental distance factory.
 */
public class DecDistFactory {

    private DecDistFactory() {
    }

    public static DecrementalDistOracle createRoddityZwick(IGraph graph, int kVal, int maxDist) {
        return new DecrementalDistOracle(graph, kVal, maxDist);
    }

}
