package apsp.com.fullydynamicapsp;

/**
 * This represents a vertex.
 */
public interface IVertex {

    /**
     * The root of the BFS tree to which this vertex belong to. If it is root or
     * it's does not belong to the BFS tree, then source vertex can be null.
     * {@link #getLevel()} can be used to check if the vertex belong connected
     * component of a vertex or not.
     * 
     * @return
     */
    // IVertex getSourceVertex();

    /**
     * This provides label of the current Vertex.
     * 
     * @return Label of the vertex.
     */
    String getLabel();

    /**
     * Returns level of the vertex with respect to source vertex. If the vertex
     * and source vertex are same then level is zero. If this vertex is not
     * reachable from source vertex then it's level is -1. Level -1 can be used
     * to understand if the vertex belong to the BFS tree or not.
     * 
     * @return Level of this vertex with respect source vertex.
     */
    int getLevel();

    /**
     * The distance between source node to this node.
     * 
     * @return Distance from root of the tree.
     */
    int getDist();

    void setDistance(int dist);

    /**
     * Represents nearest vertex.
     * 
     * @return true if it is nearest vertex, false otherwise.
     */
    boolean isNearest();

    /**
     * Sets nearest vertex status.
     * 
     * @param status
     *            true if this is nearest vertex, false otherwise.
     */
    void setNearest(boolean status);

    /**
     * Provides nearest node.
     * 
     * @return Nearest node
     */
    IVertex getNearestNode();

    /**
     * Sets nearest node to this vertex.
     * 
     * @param vertex
     *            Nearest node
     */
    void setNearestNode(IVertex vertex);

}
