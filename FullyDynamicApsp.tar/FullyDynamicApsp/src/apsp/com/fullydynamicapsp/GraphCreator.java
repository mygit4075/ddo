package apsp.com.fullydynamicapsp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class GraphCreator {

	private static final String NEW_GRAPH = "input.txt";
	private static final int DEF_NODES = 10;
	private static final int DEF_EDGES = 20;

	static boolean create() {
		return create(DEF_NODES, DEF_EDGES);
	}

	static boolean create(int nodes, int edges) {
		boolean retVal = false;
		PrintWriter writer = null;
		try {
			writer = new PrintWriter(new File(NEW_GRAPH));
			writer.println(nodes);
			writer.println(edges);
			writer.flush();

			Map<Integer, Set<Integer>> map = new HashMap<>();
			Random randm = new Random();
			for (int i = 1; i <= edges; i++) {
				int from = randm.nextInt(nodes + 1);
				int to = randm.nextInt(nodes + 1);

				if (from <= 0 || to <= 0 || from == to) {
					i--;
					continue;
				}

				Set<Integer> adj = map.get(from);
				if (adj == null) {
					adj = new HashSet<>();
					map.put(from, adj);
				}

				Set<Integer> adj2 = map.get(to);
				if (adj2 == null) {
					adj2 = new HashSet<>();
					map.put(to, adj2);
				}

				if (adj.contains(to) || adj2.contains(from)) {
					i--;
					continue;
				} else {
					adj.add(to);
					adj2.add(from);
					writer.println("" + from + " " + to);
				}
			}
			writer.flush();
			retVal = true;
		} catch (FileNotFoundException e) {
			retVal = false;
			e.printStackTrace();
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
		return retVal;
	}
}
