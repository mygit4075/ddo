package apsp.com.fullydynamicapsp;

/**
 * This is the listener which is notified about Graph changes.
 */
public interface IGraphListener {

    /**
     * This is called when a new edge is added.
     * 
     * @param edge
     *            Edge that is added
     */
    void onEdgeAdded(IEdge edge);

    /**
     * This is called when an edge is removed
     * 
     * @param edge
     *            Edge that is removed
     */
    void onEdgeRemoved(IEdge edge);

    /**
     * This is called when edge's weight is update
     * 
     * @param edge
     *            Edge that got update
     */
    void onEdgeUpdate(IEdge edge);

}
