package apsp.com.fullydynamicapsp;

/**
 * This is an implementation of {@link IEdge}
 */
public class Edge implements IEdge {

    protected int mWeight;

    private final String mSrcVertexLabl;
    private final String mDstVertexLabl;

    public Edge(int weight, String first, String second) {
        if (second == null || first == null) {
            throw new NullPointerException("First and Second Vertex of an edge can't be null");
        }

        mWeight = weight;
        mSrcVertexLabl = first;
        mDstVertexLabl = second;
    }

    @Override
    public int weight() {
        return mWeight;
    }

    @Override
    public boolean updateWeight(int weight) {
        if (weight <= 0) {
            return false;
        }
        mWeight = weight;
        return true;
    }

    @Override
    public String getSourceVertex() {
        return mSrcVertexLabl;
    }

    @Override
    public String getDestVertex() {
        return mDstVertexLabl;
    }

    @Override
    public String toString() {
        return "EDGE < Weight : " + mWeight + ", OutVertex : " + mSrcVertexLabl + ", InVertex : " + mDstVertexLabl
                + " >";
    }

    @Override
    public int hashCode() {
        int retVal = 1;
        retVal = retVal * 17 + mSrcVertexLabl.hashCode();
        retVal = retVal * 13 + mDstVertexLabl.hashCode();
        return retVal;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            throw new NullPointerException("NULL object can't be compared");
        }

        if (!(obj instanceof IEdge)) {
            throw new IllegalArgumentException("Type : " + obj.getClass().getName() + " can't be compared with "
                    + getClass().getName());
        }

        return mSrcVertexLabl.equals(((IEdge) obj).getSourceVertex())
                && mDstVertexLabl.equals(((IEdge) obj).getDestVertex());
    }
}
