package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * This represents Throup Zwick's APSP algorithm.
 */
public class ApproxDistOracle implements IApsp {
	private final IGraph mGraph;
	private final int mKVal;
	private final Map<Integer, List<String>> mWGrp;
	private final Map<String, IShortestTree> mClusters;
	private final Map<String, Set<String>> mBunchMap;

	private Map<Integer, List<String>> mVeticesGrps;
	private Map<Integer, IShortestTree> mTreeSet;

	public ApproxDistOracle(IGraph graph, int k) {
		mGraph = graph;
		mKVal = k;
		mWGrp = new HashMap<>();
		mClusters = new HashMap<>();
		mBunchMap = new HashMap<>();
		// long startTime = System.currentTimeMillis();
		prepare();
		// long endTime = System.currentTimeMillis();
		// Log.d("ThorupZwick time taken : " + (endTime -
		// startTime));
	}

	private void prepare() {
		createVertexGrps();
		createClusters();
		updateBunches();
	}

	private void createClusters() {
		mTreeSet = new HashMap<>();
		for (int i = (mKVal - 1); i >= 0; i--) {
			if (mWGrp.get(i).isEmpty()) {
				mTreeSet.put(i, mTreeSet.get(i + 1));
			} else {
				mTreeSet.put(i, new SingleSrcShortPath(mGraph, new NoController(), mVeticesGrps.get(i), "TreeSet"));
			}

			for (String vertex : mWGrp.get(i)) {
				List<String> list = new ArrayList<>();
				list.add(vertex);
				if (i == (mKVal - 1)) {
					mClusters.put(vertex, new SingleSrcShortPath(mGraph, new NoController(), list, "Cluster"));
				} else {
					mClusters.put(vertex, new SingleSrcShortPath(mGraph,
							new MapBasedController(mTreeSet.get(i + 1).getDistanceMap()), list, "Cluster"));
				}
			}
		}
	}

	private void createVertexGrps() {
		mVeticesGrps = new Sampler(mGraph.getVertices(), mKVal).sample(mWGrp);
	}

	private void updateBunches() {
		mBunchMap.clear();
		for (IShortestTree tree : mClusters.values()) {
			for (String vertex : tree.getDistanceMap().keySet()) {
				Set<String> bunches = mBunchMap.get(vertex);
				if (bunches == null) {
					bunches = new HashSet<>();
					mBunchMap.put(vertex, bunches);
				}
				bunches.add(tree.getSourceVertex());
			}
		}
	}

	@Override
	public AdvDistance distance(String source, String dest) {
		if (mBunchMap.get(source) == null || mBunchMap.get(dest) == null) {
			return null;
		}

		String tmpSrc = source;
		String tmpDest = dest;
		String w = source;
		int i = 0;
		IShortestTree tree = mClusters.get(w);
		while (!mBunchMap.get(dest).contains(w)) {
			i++;
			if (i >= mKVal) {
				break;
			}

			if (mTreeSet.get(i).getNearesetNode(dest) != null) {
				String tmp = mTreeSet.get(i).getNearesetNode(dest);
				if (mClusters.get(tmp).contains(dest)) {
					w = tmp;
					tmp = source;
					source = dest;
					dest = tmp;
				} else {
					continue;
				}
				tree = mClusters.get(w);
			}
		}

		AdvDistance dist = tree.getAdvDistance(tmpSrc, tmpDest);
		// Log.d(dist.mPath);
		return dist;
	}

}
