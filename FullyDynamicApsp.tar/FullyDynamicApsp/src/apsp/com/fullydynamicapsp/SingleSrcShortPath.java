package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;

/**
 * This is a single source shortest path tree based on Dijkstra algorithm.
 */
public class SingleSrcShortPath implements IShortestTree, IDecTree {

    private final IGraph mGraph;
    // Vertices map of the tree
    private final Map<String, Integer> mDistMap;
    private final ITreeController mController;
    private final List<String> mSources;
    private final Map<String, String> mNearestMap;
    private final Map<String, String> mPathMap;
    private final Map<String, Integer> mLevelMap;
    private final Set<String> mIncreasedVertices;
    private final String mType;

    public SingleSrcShortPath(IGraph graph, ITreeController controller, List<String> sources, String type) {
        mGraph = graph;
        mController = controller;
        mDistMap = new HashMap<>();
        mSources = sources;
        mNearestMap = new HashMap<>();
        mPathMap = new HashMap<>();
        mLevelMap = new HashMap<>();
        mIncreasedVertices = new HashSet<>();
        mType = type;
        // long startTime = System.currentTimeMillis();
        process(mSources);
        mIncreasedVertices.clear();
        // long endTime = System.currentTimeMillis();
        // Log.d("Dijkstra time taken : " + (endTime - startTime));
    }

    private void process(List<String> sources) {
        /*
         * The following is the notation for BFS(Breadth First Search).
         */
        // 0: Element is not processed
        // 1: Element is in Queue
        // 2: Element is processed

        Map<String, Integer> processedMap = new HashMap<>();
        Queue<String> queue = new LinkedList<>();

        for (String vertex : sources) {
            processedMap.put(vertex, 1);
            mLevelMap.put(vertex, 0);
            mNearestMap.put(vertex, vertex);
            mDistMap.put(vertex, 0);
            queue.add(vertex);
        }

        // int count = 0;
        // int steps = 0;

        while (!queue.isEmpty()) {
            String vertexLabel = queue.remove();
            processedMap.put(vertexLabel, 2);
            // steps++;
            if (mGraph.getAdjVertices(vertexLabel) != null) {
                for (String adjLabel : mGraph.getAdjVertices(vertexLabel).keySet()) {
                    // steps++;
                    if (mController.isAllowed(adjLabel, mDistMap.get(vertexLabel),
                            mGraph.getEdgeDistance(vertexLabel, adjLabel))) {
                        // count++;
                        int dist = mDistMap.get(vertexLabel) + mGraph.getEdgeDistance(vertexLabel, adjLabel);
                        Integer adjDist = mDistMap.get(adjLabel);
                        if (adjDist == null || adjDist > dist) {
                            mDistMap.put(adjLabel, dist);
                            mNearestMap.put(adjLabel, mNearestMap.get(vertexLabel));
                            if (adjLabel.equals(vertexLabel)) {
                                Log.d("ADJ: " + adjLabel + "Vertex : " + vertexLabel);
                                throw new RuntimeException("ADJ: " + adjLabel + "Vertex : " + vertexLabel);
                            }
                            mPathMap.put(adjLabel, vertexLabel);
                            mLevelMap.put(adjLabel, mLevelMap.get(vertexLabel) + 1);
                            mIncreasedVertices.add(adjLabel);
                        }

                        if (processedMap.get(adjLabel) == null) {
                            queue.add(adjLabel);
                            processedMap.put(adjLabel, 1);
                        }
                    } else {
                        processedMap.put(adjLabel, 2);
                    }

                }
            }
        }

        processedMap.clear();
        // Log.d("Edges Processed : " + count+" Steps : "+steps);
//        Log.d(mType + " ROOTS(" + mSources + ") : " + " Level Map : " + mLevelMap + " Dist Map : "
//                + mDistMap + " Path Map : " + mPathMap);
    }

    @Override
    public int distance(String dest) {
        if (!mDistMap.containsKey(dest)) {
            return -1;
        }
        return mDistMap.get(dest);
    }

    @Override
    public String getSourceVertex() {
        return mSources.get(0);
    }

    @Override
    public Map<String, Integer> getDistanceMap() {
        return mDistMap;
    }

    @Override
    public boolean contains(String vertexlabel) {
        return mDistMap.containsKey(vertexlabel);
    }

    @Override
    public String getNearesetNode(String vertex) {
        return mNearestMap.get(vertex);
    }

    @Override
    public AdvDistance getAdvDistance(String source, String dest) {
        AdvDistance distance = new AdvDistance();
        List<String> path = new ArrayList<>();
        path.add(dest);
//        Log.d(mType + " ROOTS(" + mSources + ") : " + " Level Map : " + mLevelMap);
//        Log.d("Distance Path Map : " + mPathMap + " Dist Map : " + mDistMap + " Path Map : " + mPathMap);
        while (mPathMap.get(dest) != null) {
            dest = mPathMap.get(dest);
            // Log.d("Path1 : " + dest);
            path.add(dest);
        }

        List<String> path2 = new ArrayList<>();
        while (source != null && !path.contains(source)) {
            path2.add(source);
            // Log.d("Path2 : " + source);
            source = mPathMap.get(source);
        }

        for (int i = path.indexOf(source); i >= 0; i--) {
            path2.add(path.get(i));
        }
        distance.mPath = path2;
        distance.mDistance = path2.size() - 1;
        return distance;
    }

    @Override
    public boolean delete(IEdge edge) {
        /*
         * Maintaining source vertex's level is not greater than destination
         * vertex. This will helps in applying Even Shiloach algorithm.
         */
        String srcVertex = edge.getSourceVertex();
        String dstVertex = edge.getDestVertex();
        if (!mLevelMap.containsKey(srcVertex) || !mLevelMap.containsKey(dstVertex)) {
//            Log.d("Sources : " + mSources + " Dist Map : " + mDistMap + " Path Map : " + mPathMap);
            return false;
        }

        mIncreasedVertices.clear();
        if (mLevelMap.get(srcVertex) != mLevelMap.get(dstVertex)) {
            if (mLevelMap.get(srcVertex) > mLevelMap.get(dstVertex)) {
                String tmp = srcVertex;
                srcVertex = dstVertex;
                dstVertex = tmp;
            }
//            Log.d("Sources : " + mSources + "SRC LEVEL(" + srcVertex + ") : " + mLevelMap.get(srcVertex)
//                    + " DST LEVEL(" + dstVertex + ") : " + mLevelMap.get(dstVertex) + " Dist Map : " + mDistMap
//                    + " Path Map : " + mPathMap);
            return deleteEdge(srcVertex, dstVertex);
        } else {
            return false;
        }

    }

    private boolean areConnected(String source, String dest) {
        boolean retVal = false;
        Deque<String> stack = new LinkedList<>();
        Map<String, Integer> visitedList = new HashMap<>();
        stack.push(source);
        visitedList.put(source, 1);
        while (!stack.isEmpty()) {
            String topVertex = stack.pop();
            if (topVertex.equals(dest)) {
                retVal = true;
                break;
            }
            visitedList.put(topVertex, 2);
            if (mGraph.getAdjVertices(topVertex) != null) {
                for (String adjVertex : mGraph.getAdjVertices(topVertex).keySet()) {
                    if (!mLevelMap.containsKey(adjVertex)) {
                        continue;
                    }
                    if (!visitedList.containsKey(adjVertex)) {
                        stack.push(adjVertex);
                        visitedList.put(adjVertex, 1);
                    }
                }
            }
        }
        stack.clear();
        return retVal;
    }

    private boolean deleteEdge(String srcVertx, String dstVertx) {
        boolean connected = areConnected(srcVertx, dstVertx);
//        Log.d("Areconnected : " + connected + " DST Has Any Adj Node : " + hasAnyAdjNode(dstVertx));
        if (connected) {
//            Log.d("Before Delelte Path Map : " + mPathMap);
//            Log.d(mType + " ROOTS(" + mSources + ") : " + " Level Map : " + mLevelMap);
            updateDistance(dstVertx);
        } else {
            removeSubTree(dstVertx);
        }

//        Log.d(mType + " ROOTS(" + mSources + ") : " + " Level Map : " + mLevelMap);
//        Log.d("After Delelte Path Map : " + mPathMap + " Dist Map: " + mDistMap);
        if (mDistMap.size() != (mPathMap.size() + mSources.size())) {
//            Log.d("ERROR!! Distance map is not matching with path map size");
//            Log.d("DIST MAP :" + mDistMap + " Path Map : " + mPathMap);
        }
        return true;
    }

    private void updateDistance(String vertex) {
        List<String> parents = getParents(vertex);
//        Log.d("Vertex : " + vertex + " Parents : " + parents);
        if (parents.isEmpty()) {
            Queue<String> levelQueue = new LinkedList<>();
            levelQueue.add(vertex);
            handleLevelChange(levelQueue);
        } else {
            mPathMap.put(vertex, parents.get(0));
        }
        parents.clear();
    }

    private List<String> getChildren(String vertex) {
        List<String> children = new LinkedList<>();
//        Log.d("Vertex (" + vertex + ") ADJ Vertices : " + mGraph.getAdjVertices(vertex).keySet());
        for (Entry<String, Integer> adjEntry : mGraph.getAdjVertices(vertex).entrySet()) {
            if (!mLevelMap.containsKey(adjEntry.getKey())) {
                continue;
            }

            if (mLevelMap.get(adjEntry.getKey()) == (mLevelMap.get(vertex) + 1)) {
                children.add(adjEntry.getKey());
            }
        }
//        Log.d("Vertex (" + vertex + ") Children : " + children);
        return children;
    }

    private List<String> getParents(String vertex) {
        List<String> parents = new LinkedList<>();
//        Log.d("Vertex (" + vertex + ") ADJ Vertices : " + mGraph.getAdjVertices(vertex).keySet());
        if (mLevelMap.containsKey(vertex)) {
            for (Entry<String, Integer> adjEntry : mGraph.getAdjVertices(vertex).entrySet()) {
                if (!mLevelMap.containsKey(adjEntry.getKey())) {
                    continue;
                }

                if ((mLevelMap.get(adjEntry.getKey()) + 1) == mLevelMap.get(vertex)) {
                    parents.add(adjEntry.getKey());
                }
            }
        }
//        Log.d("Vertex (" + vertex + ") Parents : " + parents);
        return parents;
    }

    private boolean hasAnyAdjNode(String vertex) {
        boolean retVal = false;
        if (mLevelMap.containsKey(vertex)) {
            for (Entry<String, Integer> adjEntry : mGraph.getAdjVertices(vertex).entrySet()) {
                if (mLevelMap.containsKey(adjEntry.getKey())) {
                    retVal = true;
                    break;
                }
            }
        }
        return retVal;
    }

    private void handleLevelChange(Queue<String> levelQueue) {
        while (!levelQueue.isEmpty()) {
            String head = levelQueue.remove();
            List<String> children = getChildren(head);
            mLevelMap.put(head, mLevelMap.get(head) + 1);
            mDistMap.put(head, mDistMap.get(head) + 1);
            mIncreasedVertices.add(head);
            // Log.d("handleLevelChange : " + head);
            for (String child : children) {
                List<String> parents = getParents(child);
                if (parents.isEmpty()) {
                    checkAndHandle(child, levelQueue);
                } else {
                    mPathMap.put(child, parents.get(0));
                }
                parents.clear();
            }
            children.clear();

            if (getParents(head).isEmpty()) {
                checkAndHandle(head, levelQueue);
            } else {
                mPathMap.put(head, getParents(head).get(0));
            }
        }
    }

    private void checkAndHandle(String vertex, Queue<String> levelQueue) {
        if (mController.isAllowed(mDistMap.get(vertex))) {
            levelQueue.add(vertex);
        } else {
//            Log.d("Removing Vertex : " + vertex);
            mDistMap.remove(vertex);
            mNearestMap.remove(vertex);
            mLevelMap.remove(vertex);
            mPathMap.remove(vertex);
        }
    }

    private void removeSubTree(String vertex) {
//        Log.d("Removing Sub Tree : " + vertex);
        if (mGraph.getAdjVertices(vertex) != null) {
            for (String child : getChildren(vertex)) {
                removeSubTree(child);
            }
        }
        mIncreasedVertices.add(vertex);
        mDistMap.remove(vertex);
        mLevelMap.remove(vertex);
        mNearestMap.remove(vertex);
        mPathMap.remove(vertex);
    }

    @Override
    public Set<String> increasedVertices() {
        return mIncreasedVertices;
    }
}
