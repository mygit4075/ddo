package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * This represents a sampler.
 */
public class Sampler {

    private final int mKVal;
    private final List<String> mVertices;
    private final int mSize;

    public Sampler(List<String> vertices, int k) {
        mVertices = vertices;
        mSize = mVertices.size();
        mKVal = k;
    }

    /**
     * Divides set of vertices into mKVal groups. mKVal th group will have no
     * vertices. Group number starts with 1 and ends with mKVal. I th group is
     * created from (I - 1) th group by selecting each vertex of (I - 1) group
     * with probability of 1/(n pow 1/k).
     * 
     * @return
     */
    public Map<Integer, List<String>> sample(Map<Integer, List<String>> wMap) {
        wMap.clear();
        Map<Integer, List<String>> verticesGrps = new HashMap<>();
        verticesGrps.put(mKVal, new ArrayList<String>());
        verticesGrps.put(0, mVertices);
        for (int i = 1; i < mKVal; i++) {
            verticesGrps.put(i, getVertices(i, verticesGrps.get(i - 1)));
            List<String> prevList = new ArrayList<>(verticesGrps.get(i - 1));
            prevList.removeAll(verticesGrps.get(i));
            wMap.put((i - 1), prevList);
        }
        wMap.put(mKVal - 1, verticesGrps.get(mKVal - 1));

        return verticesGrps;
    }

    private List<String> getVertices(int index, List<String> vertices) {
        List<String> retVal = new ArrayList<>();
        double kVal = mKVal;
        int numOfVertices = (int) (Math.pow(mSize, (kVal - index) / kVal) + 0.5);
        Random random = new Random();
        for (int i = 0; i < numOfVertices; i++) {
            int token = random.nextInt(vertices.size());
            if (retVal.contains(vertices.get(token))) {
                i--;
            } else {
                retVal.add(vertices.get(token));
            }
        }
        return retVal;
    }

}
