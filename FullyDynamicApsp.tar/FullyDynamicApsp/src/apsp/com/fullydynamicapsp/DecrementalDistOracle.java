package apsp.com.fullydynamicapsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * This is based on Roddity Zwick's paritial dynamic distance oracle. This
 * distance oracle handles only edge removes and not insertions. The algorithm
 * can be configured with K and maximum depth of the spanning tree.
 */
public class DecrementalDistOracle implements IDecDistOracle {

    // private static final String KROOT_PREFIX = "KROOT";

    private final IGraph mGraph;
    private final int mKVal;
    private final int mMaxDist;
    private final Map<Integer, List<String>> mWGrp;
    private final Map<String, IDecTree> mClusters;
    private final Map<String, Set<String>> mBunchMap;

    private Map<Integer, List<String>> mVeticesGrps;
    private Map<Integer, IDecTree> mTreeSet;

    public DecrementalDistOracle(IGraph graph, int k, int maxDist) {
        mGraph = graph;
        mKVal = k;
        mMaxDist = maxDist;
        mWGrp = new HashMap<>();
        mClusters = new HashMap<>();
        mBunchMap = new HashMap<>();
        // long startTime = System.currentTimeMillis();
        prepare();
        // long endTime = System.currentTimeMillis();
        // Log.d("Roddity Zwick time taken : " + (endTime -
        // startTime));
    }

    private void prepare() {
        createVertexGrps();
        createClusters();
        updateBunches();
    }

    private void createClusters() {
        mTreeSet = new HashMap<>();
        for (int i = (mKVal - 1); i >= 0; i--) {
            if (mWGrp.get(i).isEmpty()) {
                mTreeSet.put(i, mTreeSet.get(i + 1));
            } else {
                mTreeSet.put(i, new SingleSrcShortPath(mGraph, new DistanceController(mMaxDist), mVeticesGrps.get(i), "TreeSet"));
            }

            for (String vertex : mWGrp.get(i)) {
                List<String> list = new ArrayList<>();
                list.add(vertex);
                if (i == (mKVal - 1)) {
                    mClusters.put(vertex, new SingleSrcShortPath(mGraph, new NoController(), list, "Cluster"));
                } else {
                    mClusters.put(vertex, new SingleSrcShortPath(mGraph, new MapBasedController(mTreeSet.get(i + 1)
                            .getDistanceMap()), list, "Cluster"));
                }
            }
        }
    }

    private void createVertexGrps() {
        mVeticesGrps = new Sampler(mGraph.getVertices(), mKVal).sample(mWGrp);
    }

	private void updateBunches() {
		mBunchMap.clear();
		for (IShortestTree tree : mClusters.values()) {
			for (String vertex : tree.getDistanceMap().keySet()) {
				Set<String> bunches = mBunchMap.get(vertex);
				if (bunches == null) {
					bunches = new HashSet<>();
					mBunchMap.put(vertex, bunches);
				}
				bunches.add(tree.getSourceVertex());
			}
		}
	}

    private void dumpBunch() {
        for (Entry<String, Set<String>> entry : mBunchMap.entrySet()) {
            Log.d("Vertex : " + entry.getKey() + " Bunch : " + entry.getValue());
        }
    }

    // private String addZeroVertex(int index, List<String> vertices, IGraph
    // graph) {
    // String rootVertex = KROOT_PREFIX + index;
    // for (String vertex : vertices) {
    // graph.addEdge(new Edge(0, rootVertex, vertex));
    // }
    // return rootVertex;
    // }

    @Override
    public boolean remove(IEdge edge) {

        for (IDecTree tree : mTreeSet.values()) {
//            Log.d("Tree Set Removal");
            tree.delete(edge);
        }

//        Log.d("Before Cluster Removal");

        for (int i = 0; i < mKVal; i++) {
            for (String wVertex : mWGrp.get(i)) {
//                Log.d("Cluster Removal");
                mClusters.get(wVertex).delete(edge);
            }

            if (i < (mKVal - 1)) {
                for (String vertex : mTreeSet.get(i + 1).increasedVertices()) {
                    Set<String> bIV = mBunchMap.get(vertex);
                    for (Map.Entry<String, Integer> adjVertex : mGraph.getAdjVertices(vertex).entrySet()) {
                        Set<String> bIU = new HashSet<>(mBunchMap.get(adjVertex.getKey()));
                        bIU.removeAll(bIV);
                        for (String w : bIU) {
                            IDecTree tree = mClusters.get(w);
                            if (tree.contains(adjVertex.getKey())) {
                                int wu = tree.distance(adjVertex.getKey());
                                int weight = adjVertex.getValue();
                                int dist = mTreeSet.get(i + 1).distance(vertex);
                                if (dist == -1 || (wu + weight) < dist) {
                                    List<String> list = new ArrayList<>();
                                    list.add(w);
                                    mClusters.put(w, new SingleSrcShortPath(mGraph, new MapBasedController(mTreeSet.get(i + 1)
                                            .getDistanceMap()), list, "Cluster"));
                                }
                            }
                        }
                    }
                }
            }
        }

        updateBunches();
        return true;
    }

    @Override
    public AdvDistance distance(String source, String dest) {
        if (mBunchMap.get(source) == null || mBunchMap.get(dest) == null) {
            return null;
        }

//        Log.d("Distance Between : <" + source + " , " + dest + " >");
//        Log.d("Bunch Map : " + mBunchMap);
//        Log.d(mWGrp.get(mKVal - 1).toString());
        // for (int i = 0; i < mWGrp.get(mKVal - 1).size(); i++) {
        // Log.d("" + mClusters.get(mWGrp.get(mKVal - 1).get(i)));
        // }

        String tmpSrc = source;
        String tmpDest = dest;
        String w = source;
        int i = 0;
        IDecTree tree = mClusters.get(w);
        while (!mBunchMap.get(dest).contains(w)) {
            i++;
            if (i >= mKVal) {
                break;
            }

            if (mTreeSet.get(i).getNearesetNode(dest) != null) {
                String tmp = mTreeSet.get(i).getNearesetNode(dest);
                if (mClusters.get(tmp).contains(dest)) {
                    w = tmp;
                    tmp = source;
                    source = dest;
                    dest = tmp;
                    tree = mClusters.get(w);
                } else {
                    continue;
                }
            }
        }

        if (tree == null || !tree.contains(source) || !tree.contains(dest)) {
            // Log.d("Tree does not have the node " + tree);
            return null;
        }

        AdvDistance dist = tree.getAdvDistance(tmpSrc, tmpDest);
        // Log.d(dist.mPath);
        return dist;
    }

    @Override
    public boolean add(IEdge edge) {
        // TODO If possible segregate interfaces.
        throw new RuntimeException("Not supported!!");
    }

    @Override
    public Map<Integer, String> getNearestNodes(String vertex) {
        Map<Integer, String> retVal = new HashMap<>();
        for (int i = 0; i < mKVal; i++) {
            retVal.put(i, mTreeSet.get(i).getNearesetNode(vertex));
        }
        return retVal;
    }
}
