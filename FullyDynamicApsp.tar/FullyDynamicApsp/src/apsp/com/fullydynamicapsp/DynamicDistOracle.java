package apsp.com.fullydynamicapsp;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import apsp.com.fullydynamicapsp.IShortestTree.AdvDistance;

/**
 * This represents an undirected and unweighted graph based on Fully Dynamic
 * All-Pairs Shortest Paths: Breaking the O(n) Barrier by Ittai Abraham, Shiri
 * Chechik, and Kunal Talwar.
 */
public class DynamicDistOracle implements IFullyDynmApsp {

	private final int mKVal;
	private final int mEdgeLimit;
	private IDecDistOracle mRodditOracle;
	private IApsp mTzOracle;
	private IGraph mGraph;
	private IGraph mUGraph;
	private final Set<IEdge> mAddedEdges;
	private boolean hasChanged = false;

	public DynamicDistOracle(IGraph graph, int kVal) {
		mKVal = kVal;
		mGraph = graph.duplicate();
		mEdgeLimit = (int) Math.pow(mGraph.getEdges().size(), 1.0 / 2);
		mRodditOracle = DecDistFactory.createRoddityZwick(mGraph, mKVal, mGraph.numOfVertices());
		mAddedEdges = new HashSet<>();
	}

	@Override
	public boolean delete(IEdge edge) {
		long startTime = System.currentTimeMillis();
		// Log.i("Delete Edge Source :" + edge.getSourceVertex() + " Dest :" +
		// edge.getDestVertex());
		boolean retVal = mGraph.getEdges().contains(edge);
		if (retVal) {
			mGraph.deleteEdge(edge);
			mRodditOracle.remove(edge);
			if (mAddedEdges.remove(edge)) {
				hasChanged = true;
			}

			if (mAddedEdges.remove(new Edge(edge.weight(), edge.getDestVertex(), edge.getSourceVertex()))) {
				hasChanged = true;
			}

//			if (hasChanged) {
//				createTz();
//			}
		}
		long endTime = System.currentTimeMillis();
//		Log.i("Delete Time : " + (endTime - startTime));
		return retVal;
	}

	@Override
	public boolean add(IEdge edge) {
		long startTime = System.currentTimeMillis();
		boolean retVal = mAddedEdges.add(edge);
		// Log.i("Add Edge Source :" + edge.getSourceVertex() + " Dest :" +
		// edge.getDestVertex());
		if (retVal) {
			if (mEdgeLimit <= mAddedEdges.size()) {
				Log.d("RE CREATE!!");
				// Need to recreate entire data structure
				for (IEdge newEdge : mAddedEdges) {
					mGraph.addEdge(newEdge);
				}
				mGraph.prepare();
				mAddedEdges.clear();
				mUGraph = new ModernAdjList(0);
				mRodditOracle = DecDistFactory.createRoddityZwick(mGraph, mKVal, mGraph.numOfVertices());
				mTzOracle = null;
			} else {
				hasChanged = true;
//				createTz();
			}
		}
		long endTime = System.currentTimeMillis();
//		Log.i("Add Time :" + (endTime - startTime));
		return retVal;
	}

	private void createTz() {
		mUGraph = new ModernAdjList(0);
		for (IEdge addedEdge : mAddedEdges) {
			addUEdge(addedEdge);
		}
		mUGraph.prepare();
		mTzOracle = new ApproxDistOracle(mUGraph, mKVal);
	}

	private void addUEdge(IEdge edge) {
		String srcVertex = edge.getSourceVertex();
		String dstVertex = edge.getDestVertex();
		Map<Integer, String> srcMap = mRodditOracle.getNearestNodes(srcVertex);
		Map<Integer, String> dstMap = mRodditOracle.getNearestNodes(dstVertex);
		for (String bVrtx : srcMap.values()) {
			if (bVrtx == null) {
				continue;
			}
			if (srcVertex.equals(bVrtx)) {
				continue;
			}
			AdvDistance dist = mRodditOracle.distance(srcVertex, bVrtx);
			if (dist == null) {
				continue;
			}
			mUGraph.addEdge(new Edge(dist.mDistance, srcVertex, bVrtx));
		}
		mUGraph.addEdge(edge);
		for (String bVrtx : dstMap.values()) {
			if (bVrtx == null) {
				continue;
			}

			if (dstVertex.equals(bVrtx)) {
				continue;
			}

			AdvDistance dist = mRodditOracle.distance(dstVertex, bVrtx);
			if (dist == null) {
				continue;
			}
			mUGraph.addEdge(new Edge(dist.mDistance, dstVertex, bVrtx));
		}
	}

	@Override
	public AdvDistance distance(String source, String dest) {
		if(hasChanged){
			createTz();
			hasChanged = false;
		}
		// Log.i("Distance Between Source : " + source + " Dest : " + dest);
		long startTime = System.currentTimeMillis();
		AdvDistance dist = mRodditOracle.distance(source, dest);
		if (dist != null) {
			Log.d(dist.mPath.toString());
			if (mTzOracle != null) {
				Map<Integer, String> srcMap = mRodditOracle.getNearestNodes(source);
				Map<Integer, String> dstMap = mRodditOracle.getNearestNodes(dest);
				for (int i = 0; i < mKVal; i++) {
					String pSrc = srcMap.get(i);
					if (pSrc == null) {
						continue;
					}
					for (int j = 0; j < mKVal; j++) {
						String pDst = dstMap.get(j);
						if (pDst == null) {
							continue;
						}
						if (mRodditOracle.distance(source, pSrc) == null) {
							continue;
						}

						if (mTzOracle.distance(pSrc, pDst) == null) {
							continue;
						}

						if (mRodditOracle.distance(pDst, dest) == null) {
							continue;
						}

						List<String> path = new LinkedList<>();
						AdvDistance tmp = mRodditOracle.distance(source, pSrc);
						// Log.d(" RZ DIST Source : " + source + " Dest : " +
						// pSrc + " :: " + tmp.mPath);
						for (String vertex : tmp.mPath) {
							path.add(vertex);
						}

						tmp = mTzOracle.distance(pSrc, pDst);
						// Log.d(" TZ DIST Source : " + pSrc + " Dest : " + pDst
						// + " :: " + tmp.mPath);
						for (int k = 1; k < tmp.mPath.size(); k++) {
							path.add(tmp.mPath.get(k));
						}

						tmp = mRodditOracle.distance(pDst, dest);
						// Log.d(" RZ DIST Source : " + pDst + " Dest : " + dest
						// + " :: " + tmp.mPath);
						for (int k = 1; k < tmp.mPath.size(); k++) {
							path.add(tmp.mPath.get(k));
						}

						if (dist == null || (path.size() < dist.mPath.size())) {
							dist = new AdvDistance();
							dist.mPath = path;
							dist.mDistance = path.size() - 1;
						}
					}
				}
			}
		}
		long endTime = System.currentTimeMillis();
//		Log.i("DiST Time : " + (endTime - startTime));
		return dist;
	}
}
