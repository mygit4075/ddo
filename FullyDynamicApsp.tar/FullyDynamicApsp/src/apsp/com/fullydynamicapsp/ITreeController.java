package apsp.com.fullydynamicapsp;

/**
 * This controls depth of a shortest path tree.
 */
public interface ITreeController {

    /**
     * This method is supposed to determine if we can add the given child to the
     * specified parent.
     * 
     * @param parent
     *            Parent
     * @param child
     *            Child
     * @param weight
     *            Weight of the edge between the two given nodes
     * @return true if the child can be added to the given parent, false
     *         otherwise.
     */
    boolean isAllowed(String vertex, int dist, int weight);

    boolean isAllowed(int level);
}
