package apsp.com.fullydynamicapsp;

/**
 * This is an implementation of Even Shiloach edge.
 */
public class EsEdge extends Edge implements IEsEdge {

    /*
     * private final IESVertex mFirstVertex; private final IESVertex
     * mSecondVertex;
     */

    public EsEdge(String label, int weight, String first, String second) {
        super(weight, first, second);
        /*
         * mFirstVertex = first; mSecondVertex = second;
         */
    }

    @Override
    public boolean remove() {
        /*
         * int firstLevel = mFirstVertex.getLevel(); int secondLevel =
         * mSecondVertex.getLevel();
         * 
         * if(firstLevel == secondLevel) {
         * mFirstVertex.removeEdge(IESVertex.AdjType.SIBLING, mSecondVertex);
         * mSecondVertex.removeEdge(IESVertex.AdjType.SIBLING, mFirstVertex); }
         * else if(firstLevel > secondLevel) {
         * mFirstVertex.removeEdge(IESVertex.AdjType.PARENT, mSecondVertex);
         * mSecondVertex.removeEdge(IESVertex.AdjType.CHILD, mFirstVertex); }
         * else { mFirstVertex.removeEdge(IESVertex.AdjType.CHILD,
         * mSecondVertex); mSecondVertex.removeEdge(IESVertex.AdjType.PARENT,
         * mFirstVertex); }
         */

        // TODO Is it correct to return true always??
        return true;
    }

}
