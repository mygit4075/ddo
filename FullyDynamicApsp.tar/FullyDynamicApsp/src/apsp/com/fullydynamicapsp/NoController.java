package apsp.com.fullydynamicapsp;

/**
 * This allows to add anything.
 */
public class NoController implements ITreeController {

    @Override
    public boolean isAllowed(String parent, int dist, int weight) {
        return true;
    }

    @Override
    public boolean isAllowed(int level) {
        return true;
    }

}
