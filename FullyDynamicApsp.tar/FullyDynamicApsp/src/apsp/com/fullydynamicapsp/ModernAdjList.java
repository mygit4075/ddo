package apsp.com.fullydynamicapsp;

import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.util.Set;

/**
 * This represents undirected and unweighted graph, in which set of edges and
 * adjacency vertices are maintained.
 */
public class ModernAdjList implements IGraph {

	private int mConnectedCount;
	private final Set<IEdge> mEdges;
	private final Map<String, Map<String, Integer>> mAdjVertices;
	private final Map<String, Integer> mComponentMap;
	private final Map<Integer, Integer> mCompCount;
	private final Set<IGraphListener> mListeners;
	private final int numOfNodes;
	private final List<String> mVertices;
	private final List<String> mSources;

	public ModernAdjList(int n) {
		mEdges = new HashSet<>();
		mAdjVertices = new HashMap<>();
		mComponentMap = new HashMap<>();
		mListeners = new HashSet<>();
		mConnectedCount = 0;
		numOfNodes = n;
		mCompCount = new HashMap<>();
		mVertices = new LinkedList<>();
		mSources = new LinkedList<>();
	}

	public ModernAdjList(ModernAdjList othrGrph) {
		this(othrGrph.numOfNodes);
	}

	@Override
	public IGraph duplicate() {
		ModernAdjList graph = new ModernAdjList(this);
		graph.mEdges.addAll(mEdges);
		for (Entry<String, Map<String, Integer>> entry : mAdjVertices.entrySet()) {
			Map<String, Integer> newMap = new HashMap<>();
			newMap.putAll(entry.getValue());
			graph.mAdjVertices.put(entry.getKey(), newMap);
		}

		graph.mCompCount.putAll(mCompCount);
		graph.mSources.addAll(mSources);
		graph.mComponentMap.putAll(mComponentMap);
		graph.mConnectedCount = mConnectedCount;
		graph.mVertices.addAll(mVertices);
		return graph;
	}

	@Override
	public List<String> getVertices() {
		return Collections.unmodifiableList(mVertices);
	}

	@Override
	public Map<String, Integer> getAdjVertices(String vertex) {
		if (mAdjVertices.get(vertex) == null) {
			return null;
		}
		return Collections.unmodifiableMap(mAdjVertices.get(vertex));
	}

	@Override
	public Set<IEdge> getEdges() {
		return Collections.unmodifiableSet(mEdges);
	}

	@Override
	public int getEdgeDistance(String source, String dests) {
		return mAdjVertices.get(source).get(dests);
	}

	@Override
	public boolean hasVertex(String vertex) {
		return mVertices.contains(vertex);
	}

	@Override
	public boolean deleteEdge(IEdge edge) {
		if (edge.getSourceVertex().equals(edge.getDestVertex())) {
			return false;
		}

		Log.d("Removing Edge: " + edge);
		boolean retVal = mEdges.remove(edge);
		mEdges.remove(new Edge(edge.weight(), edge.getDestVertex(), edge.getSourceVertex()));
		Log.d("Edge Removal Result : " + retVal);
		if (retVal) {
			String source = edge.getSourceVertex();
			String dest = edge.getDestVertex();

			mAdjVertices.get(source).remove(dest);
			mAdjVertices.get(dest).remove(source);

			updateComponentMap(source, dest);
			notifyEdgeRemoval(edge);
		}
		return retVal;
	}

	private void notifyEdgeRemoval(IEdge edge) {
		for (IGraphListener listener : mListeners) {
			listener.onEdgeRemoved(edge);
		}
	}

	private boolean updateComponentMap(String vertex1, String vertex2) {
		boolean retVal = false;
		Deque<String> stack = new LinkedList<>();
		Map<String, Integer> visitedList = new HashMap<>();

		stack.push(vertex1);
		visitedList.put(vertex1, 1);
		while (!stack.isEmpty()) {
			String topVertex = stack.pop();
			if (topVertex.equals(vertex2)) {
				retVal = true;
				break;
			}
			visitedList.put(topVertex, 2);
			if (mAdjVertices.get(topVertex) != null) {
				for (String adjVertex : mAdjVertices.get(topVertex).keySet()) {
					if (!visitedList.containsKey(adjVertex)) {
						stack.push(adjVertex);
						visitedList.put(adjVertex, 1);
					}
				}
			}
		}

		if (!retVal) {
			Log.d("Disconnected V1 : " + vertex1 + " V2: " + vertex2);
			mConnectedCount++;
			for (String vertex : visitedList.keySet()) {
				mComponentMap.put(vertex, mConnectedCount);
			}

			boolean hasMatched = false;
			for (String source : mSources) {
				if (mComponentMap.get(source) == mComponentMap.get(vertex1)) {
					hasMatched = true;
					break;
				}
			}

			if (hasMatched) {
				if (!mSources.contains(vertex2)) {
					mSources.add(vertex2);
				}
			} else {
				if (!mSources.contains(vertex1)) {
					mSources.add(vertex1);
				}
			}
		}

//		Log.d("Component Map : " + mComponentMap + " Sources : " + mSources + " hash code : " + hashCode());

		return retVal;
	}

	@Override
	public boolean areConnected(String vertex1, String vertex2) throws IllegalOpException {
		if (!mAdjVertices.containsKey(vertex1) || !mAdjVertices.containsKey(vertex2)) {
			throw new IllegalOpException(
					"" + vertex1.toString() + " or " + vertex2.toString() + " is not part of the Graph!!");
		}
		return mComponentMap.get(vertex1) == mComponentMap.get(vertex2);
	}

	@Override
	public int numOfVertices() {
		return mVertices.size();
	}

	@Override
	public boolean addListener(IGraphListener listener) {
		if (listener == null) {
			throw new NullPointerException("Listener can't be null!!");
		}
		return mListeners.add(listener);
	}

	@Override
	public boolean removeListener(IGraphListener listener) {
		if (listener == null) {
			throw new NullPointerException("Listener can't be null!!");
		}
		return mListeners.remove(listener);
	}

	private void notifyEdgeAddition(IEdge edge) {
		for (IGraphListener listener : mListeners) {
			listener.onEdgeAdded(edge);
		}
	}

	@Override
	public boolean addEdge(IEdge edge) {
		if (edge.getSourceVertex().equals(edge.getDestVertex())) {
			return false;
		}

		boolean retVal = mEdges.add(edge);
		mEdges.add(new Edge(edge.weight(), edge.getDestVertex(), edge.getSourceVertex()));
		if (retVal) {
			handleEdgeAddition(edge);
			notifyEdgeAddition(edge);
		}
		return retVal;
	}

	private void handleEdgeAddition(IEdge edge) {
		String source = edge.getSourceVertex();
		if (!mVertices.contains(source)) {
			mVertices.add(source);
		}

		String dest = edge.getDestVertex();
		if (!mVertices.contains(dest)) {
			mVertices.add(dest);
		}

		Map<String, Integer> adjMap = mAdjVertices.get(source);
		if (adjMap == null) {
			adjMap = new HashMap<>();
			mAdjVertices.put(source, adjMap);
		}
		adjMap.put(dest, edge.weight());

		adjMap = mAdjVertices.get(dest);
		if (adjMap == null) {
			adjMap = new HashMap<>();
			mAdjVertices.put(dest, adjMap);
		}
		adjMap.put(source, edge.weight());
	}

	@Override
	public boolean addVertex(String vertex) {
		if (mVertices.contains(vertex)) {
			return false;
		}

		mVertices.add(vertex);
		return true;
	}

	@Override
	public int numOfComponents() {
		return mConnectedCount;
	}

	@Override
	public List<String> getComponentSource() {
		return mSources;
	}

	private void prepareConnectedComponent(String source) {
		Map<String, Integer> processedMap = new HashMap<>();
		Queue<String> queue = new LinkedList<>();
		queue.add(source);
		mSources.add(source);
		mConnectedCount++;
		mComponentMap.put(source, mConnectedCount);
		int count = 1;
		int steps = 0;
		while (!queue.isEmpty()) {
			String vertexLabel = queue.remove();
			processedMap.put(vertexLabel, 2);
			steps++;
			if (mAdjVertices.get(vertexLabel) != null) {
				for (String adjLabel : mAdjVertices.get(vertexLabel).keySet()) {
					steps++;
					if (processedMap.get(adjLabel) == null) {
						count++;
						queue.add(adjLabel);
						processedMap.put(adjLabel, 1);
						mComponentMap.put(adjLabel, mConnectedCount);
					}
				}
			}
		}

		mCompCount.put(mConnectedCount, count);

		processedMap.clear();
		Log.d("Edges Processed : " + count + " Steps : " + steps);
	}

	@Override
	public void prepare() {
		mConnectedCount = 0;
		mComponentMap.clear();
		mSources.clear();
		Log.d("Edges: " + mEdges);
		for (int i = 0; i < numOfNodes; i++) {
			if (!mVertices.contains(String.valueOf(i + 1))) {
				mVertices.add(String.valueOf(i + 1));
			}
			if (!mComponentMap.containsKey(mVertices.get(i))) {
				prepareConnectedComponent(mVertices.get(i));
			}
		}
	}
}
