package apsp.com.fullydynamicapsp;

import java.util.Random;

public class StatisticsAnalyzer {

	public static void main(String[] args) {
		(new GraphCreator()).create();
		IGraph graph = GraphReader.readGraph();
		Log.i("Graph Created!");
		long startTime = System.currentTimeMillis();
		DynamicDistOracle mApsp = new DynamicDistOracle(graph, 15);
		long endTime = System.currentTimeMillis();
		Log.i("Preprocessing Time :" + (endTime - startTime));

		startTime = System.currentTimeMillis();
		Random random = new Random();
		for (int i = 1; i <= 1000; i++) {
			int from = random.nextInt(10001);
			int to = random.nextInt(10001);
			if (from == to || from == 0 || to == 0) {
				i--;
				continue;
			}

			int action = random.nextInt(30);
			String node1 = String.valueOf(from);
			String node2 = String.valueOf(to);
			boolean areAdjacent = false;
			if (graph.getAdjVertices(node1) != null) {
				areAdjacent = graph.getAdjVertices(node1).containsKey(node2);
			}

			if ((action % 2) == 0) {
				if (areAdjacent) {
					mApsp.delete(new Edge(1, node1, node2));
				} else {
					mApsp.add(new Edge(1, node1, node2));
				}
			} else {
				mApsp.distance(node1, node2);
			}

		}
		endTime = System.currentTimeMillis();
		Log.i("1000 Op Time : " + (endTime - startTime));
	}

}
