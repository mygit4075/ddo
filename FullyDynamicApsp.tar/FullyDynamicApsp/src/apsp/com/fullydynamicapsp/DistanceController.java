package apsp.com.fullydynamicapsp;

/**
 * Created by sivareddy.r on 24/4/2017.
 */

public class DistanceController implements ITreeController {

    private final int mMaxDist;

    public DistanceController(int level) {
        mMaxDist = level;
    }

    @Override
    public boolean isAllowed(String vertex, int dist, int weight) {
        return dist + weight <= mMaxDist;
    }

    @Override
    public boolean isAllowed(int level) {
        return true;
    }

}
