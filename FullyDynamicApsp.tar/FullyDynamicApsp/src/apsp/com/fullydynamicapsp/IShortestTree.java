package apsp.com.fullydynamicapsp;

import java.util.List;
import java.util.Map;

/**
 * This represents single source shortest path tree.
 */
public interface IShortestTree {

    class AdvDistance {
        public int mDistance;
        public List<String> mPath;
    }

    /**
     * The distance of root node.
     */
    int ROOT_DIST = 0;

    /**
     * Level of root node
     */
    int ROOT_LEVEL = 0;

    /**
     * This represents no distance.
     */
    int NO_DIST = -1;

    /**
     * Returns distance between root and given Vertex.
     * 
     * @param dest
     *            Destination vertex
     * @return distance, -1 if distance can't be given
     */
    int distance(String dest);

    /**
     * This provides distance between two given nodes and path.
     * 
     * @return Advanced distance
     */
    AdvDistance getAdvDistance(String source, String dest);

    /**
     * Source of this shortest path tree.
     * 
     * @return Source of the shortest path tree.
     */
    String getSourceVertex();

    /**
     * Distance map of this tree.
     * 
     * @return Distance map
     */
    Map<String, Integer> getDistanceMap();

    /**
     * Checks if a given Vertex is part of this graph or nots.
     * 
     * @param vertexlabel
     *            label of the vertex
     * @return true if it contains, false otherwise.
     */
    boolean contains(String vertexlabel);

    String getNearesetNode(String vertex);
}
